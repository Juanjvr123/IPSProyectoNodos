#region Using directives

using System;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Runtime.ConstrainedExecution;

#endregion

//
// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
//
[assembly: AssemblyTitle(@"")]
[assembly: AssemblyDescription(@"")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany(@"IPS")]
[assembly: AssemblyProduct(@"NodosTelefonia")]
[assembly: AssemblyCopyright("")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: System.Resources.NeutralResourcesLanguage("en")]

//
// Version information for an assembly consists of the following four values:
//
//      Major Version
//      Minor Version 
//      Build Number
//      Revision
//
// You can specify all the values or you can default the Revision and Build Numbers 
// by using the '*' as shown below:

[assembly: AssemblyVersion(@"1.0.0.0")]
[assembly: ComVisible(false)]
[assembly: CLSCompliant(true)]
[assembly: ReliabilityContract(Consistency.MayCorruptProcess, Cer.None)]

//
// Make the Dsl project internally visible to the DslPackage assembly
//
[assembly: InternalsVisibleTo(@"IPS.NodosTelefonia.DslPackage, PublicKey=0024000004800000940000000602000000240000525341310004000001000100F9B834970019A3C8E75C61FC41B21C5CF4B14D277462A14657A62C1A3EDE8EAA798AD7837BFDC0E241025BB5245515B58CB07AB2F7FE920996AE2468760B36B31C662C69F5D6887CDAB3A437CA010684578BE079E55107AE9F6A05D404BE652A7F4EE33EEBCD6E63B0BCBC8732427EA552327CABE089D9E067AC7A62C11F43B1")]